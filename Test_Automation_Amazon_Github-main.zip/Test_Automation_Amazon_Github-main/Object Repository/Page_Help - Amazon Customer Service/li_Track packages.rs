<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Track packages</name>
   <tag></tag>
   <elementGuidId>a7700aff-e3d2-4fc3-a2f1-2e233875d634</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div[5]/div/div/div/div/a/div/div/div/div[2]/ul/li</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.a-column.a-span9.ss-rich-card-column-text.a-span-last > ul.a-unordered-list.a-nostyle.a-vertical > li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>eca3879a-7612-4f3c-b6af-15198b65dfda</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                            Track packages
                                                        </value>
      <webElementGuid>ea1c2415-ff96-45c5-a45a-0ab348499566</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[1]/div[@class=&quot;a-row&quot;]/div[@class=&quot;a-column a-span12&quot;]/div[@class=&quot;a-section a-spacing-large ss-landing-container-wide&quot;]/div[@class=&quot;a-row a-spacing-large a-spacing-top-micro ss-rich-card-row&quot;]/div[@class=&quot;a-column a-span4&quot;]/a[@class=&quot;a-color-base a-link-normal a-text-normal&quot;]/div[@class=&quot;a-box self-service-rich-card&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-row a-grid-vertical-align a-grid-top&quot;]/div[@class=&quot;a-column a-span9 ss-rich-card-column-text a-span-last&quot;]/ul[@class=&quot;a-unordered-list a-nostyle a-vertical&quot;]/li[1]</value>
      <webElementGuid>aaeb8864-ab6b-421d-98c1-913275b67c5a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div[5]/div/div/div/div/a/div/div/div/div[2]/ul/li</value>
      <webElementGuid>a70013f0-6bac-4cea-9780-03648c58a8be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li</value>
      <webElementGuid>aba64512-61ae-4842-aa44-93c82a2186f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = '
                                                            Track packages
                                                        ' or . = '
                                                            Track packages
                                                        ')]</value>
      <webElementGuid>58f8cc00-eadc-4969-9ab1-dfb78fcd46e7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
