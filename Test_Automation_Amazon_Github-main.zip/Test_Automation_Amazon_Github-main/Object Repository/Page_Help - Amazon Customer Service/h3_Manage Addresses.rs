<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Manage Addresses</name>
   <tag></tag>
   <elementGuidId>d4b64539-6ff1-4e38-9f41-8c62fe475f9c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div[5]/div/div/div/div[3]/a/div/div/div/div[2]/h3</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.a-column.a-span4.a-span-last > a.a-color-base.a-link-normal.a-text-normal > div.a-box.self-service-rich-card > div.a-box-inner > div.a-row.a-grid-vertical-align.a-grid-top > div.a-column.a-span9.ss-rich-card-column-text.a-span-last > h3.a-spacing-none.a-text-normal</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>1d960c20-e3b9-4b01-9ab1-0fe9974b86a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-spacing-none a-text-normal</value>
      <webElementGuid>75baa500-2077-4c20-a058-d5533e35378c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                    Manage Addresses
                                                </value>
      <webElementGuid>381b8964-2a80-483d-8ac8-9de408b99758</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[1]/div[@class=&quot;a-row&quot;]/div[@class=&quot;a-column a-span12&quot;]/div[@class=&quot;a-section a-spacing-large ss-landing-container-wide&quot;]/div[@class=&quot;a-row a-spacing-large a-spacing-top-micro ss-rich-card-row&quot;]/div[@class=&quot;a-column a-span4 a-span-last&quot;]/a[@class=&quot;a-color-base a-link-normal a-text-normal&quot;]/div[@class=&quot;a-box self-service-rich-card&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-row a-grid-vertical-align a-grid-top&quot;]/div[@class=&quot;a-column a-span9 ss-rich-card-column-text a-span-last&quot;]/h3[@class=&quot;a-spacing-none a-text-normal&quot;]</value>
      <webElementGuid>61b4b543-84be-40f8-ace2-351b6babfe9a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div[5]/div/div/div/div[3]/a/div/div/div/div[2]/h3</value>
      <webElementGuid>ceb13393-fbe6-49f5-952b-914b25f7a519</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/a/div/div/div/div[2]/h3</value>
      <webElementGuid>62d557b2-99f0-4b1f-b9d8-c0ac07aa2d0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = '
                                                    Manage Addresses
                                                ' or . = '
                                                    Manage Addresses
                                                ')]</value>
      <webElementGuid>69992a37-cfc4-4f95-b7de-4bff2e7cc180</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
