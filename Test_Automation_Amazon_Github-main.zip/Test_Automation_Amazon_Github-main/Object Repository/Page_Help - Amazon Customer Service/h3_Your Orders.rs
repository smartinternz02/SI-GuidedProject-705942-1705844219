<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Your Orders</name>
   <tag></tag>
   <elementGuidId>5026e7a1-18ba-4e25-a8e0-317fca0d1508</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div[5]/div/div/div/div/a/div/div/div/div[2]/h3</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h3.a-spacing-none.a-text-normal</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>606a29ef-aac0-461b-8862-0b6405741de6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-spacing-none a-text-normal</value>
      <webElementGuid>3e151f5a-e4f1-4d21-ae8c-666a60a33380</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                    Your Orders
                                                </value>
      <webElementGuid>5e116868-2e77-4e38-b13b-144ad4270f98</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[1]/div[@class=&quot;a-row&quot;]/div[@class=&quot;a-column a-span12&quot;]/div[@class=&quot;a-section a-spacing-large ss-landing-container-wide&quot;]/div[@class=&quot;a-row a-spacing-large a-spacing-top-micro ss-rich-card-row&quot;]/div[@class=&quot;a-column a-span4&quot;]/a[@class=&quot;a-color-base a-link-normal a-text-normal&quot;]/div[@class=&quot;a-box self-service-rich-card&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-row a-grid-vertical-align a-grid-top&quot;]/div[@class=&quot;a-column a-span9 ss-rich-card-column-text a-span-last&quot;]/h3[@class=&quot;a-spacing-none a-text-normal&quot;]</value>
      <webElementGuid>f670b765-7325-4c06-91ac-3701c6cc5243</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div[5]/div/div/div/div/a/div/div/div/div[2]/h3</value>
      <webElementGuid>6ec190c8-72be-489e-a8b3-8247e4dd965b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h3</value>
      <webElementGuid>5237604f-4485-46a1-87c3-52956237a9a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = '
                                                    Your Orders
                                                ' or . = '
                                                    Your Orders
                                                ')]</value>
      <webElementGuid>8c7c76b9-b78a-4cb8-8967-8fc43ca9b5d1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
