<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Gift Cards  Mobile Recharges</name>
   <tag></tag>
   <elementGuidId>e94c3921-f31c-4e62-be96-5ee0b487d32d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='hmenu-content']/ul/li[23]/a/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(23) > a.hmenu-item > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>75bfdc8c-1a71-4b9c-a195-bd2e5b1274c2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Gift Cards &amp; Mobile Recharges</value>
      <webElementGuid>e30181cf-40f5-4998-8fe9-82056dae49fe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;hmenu-content&quot;)/ul[@class=&quot;hmenu hmenu-visible&quot;]/li[23]/a[@class=&quot;hmenu-item&quot;]/div[1]</value>
      <webElementGuid>00e37a12-9686-45be-9a6f-a3dddb8210f2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='hmenu-content']/ul/li[23]/a/div</value>
      <webElementGuid>56a91f77-f2dd-46ca-baca-7ca95f4ba62a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[23]/a/div</value>
      <webElementGuid>566364a7-4e45-439c-b28d-78b6794c0342</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Gift Cards &amp; Mobile Recharges' or . = 'Gift Cards &amp; Mobile Recharges')]</value>
      <webElementGuid>89458cc0-6de5-4297-8323-61ea81a77d89</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
