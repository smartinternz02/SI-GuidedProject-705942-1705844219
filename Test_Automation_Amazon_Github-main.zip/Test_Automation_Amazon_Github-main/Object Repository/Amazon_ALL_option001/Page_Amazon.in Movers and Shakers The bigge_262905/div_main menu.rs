<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_main menu</name>
   <tag></tag>
   <elementGuidId>93a23825-1001-49d6-87ca-cf41b8fdc9fb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='hmenu-content']/ul[11]/li/a/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.hmenu.hmenu-visible.hmenu-translateX > li > a.hmenu-item.hmenu-back-button > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>9f1ac806-8bf9-4aa3-acf3-8e475eb14cae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>main menu</value>
      <webElementGuid>10f4cf91-e852-491f-b895-4a453a196349</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;hmenu-content&quot;)/ul[@class=&quot;hmenu hmenu-visible hmenu-translateX&quot;]/li[1]/a[@class=&quot;hmenu-item hmenu-back-button&quot;]/div[1]</value>
      <webElementGuid>7deaf704-5634-440c-81d2-3896a48aefd0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='hmenu-content']/ul[11]/li/a/div</value>
      <webElementGuid>ab42d35b-491b-45c8-aa6e-5f2821253b09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//ul[11]/li/a/div</value>
      <webElementGuid>30992ab7-bf5c-40a7-8cca-5d7a2ec0aae2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'main menu' or . = 'main menu')]</value>
      <webElementGuid>a5535895-8533-49c6-b6dc-0f6f89ead261</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
