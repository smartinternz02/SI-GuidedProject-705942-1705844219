<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_TV, Appliances, Electronics</name>
   <tag></tag>
   <elementGuidId>4874f6f9-8c78-479e-a41c-17319dfee740</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='hmenu-content']/ul/li[16]/a/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(16) > a.hmenu-item > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>d7b77b48-cc74-42bb-acac-6fb821ec7e80</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>TV, Appliances, Electronics</value>
      <webElementGuid>3ed6903b-428c-419a-a835-a65cd8fac56a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;hmenu-content&quot;)/ul[@class=&quot;hmenu hmenu-visible hmenu-translateX&quot;]/li[16]/a[@class=&quot;hmenu-item&quot;]/div[1]</value>
      <webElementGuid>72c448d4-67f4-4a29-9700-a920c7bfd8e2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='hmenu-content']/ul/li[16]/a/div</value>
      <webElementGuid>aadc55c7-35f9-47f2-b4de-fd698f5a1cd9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[16]/a/div</value>
      <webElementGuid>99208618-2731-4399-9f2f-ec552553184f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'TV, Appliances, Electronics' or . = 'TV, Appliances, Electronics')]</value>
      <webElementGuid>b5a649ab-84b3-43b8-9620-8f90dc2f78ab</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
