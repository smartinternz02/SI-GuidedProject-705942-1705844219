<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Mobiles, Computers</name>
   <tag></tag>
   <elementGuidId>354d5dc7-8ff6-4a6e-a356-5bd4e5a24337</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='hmenu-content']/ul/li[15]/a/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(15) > a.hmenu-item > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>f5607444-2e82-4622-957f-663fb2e458ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Mobiles, Computers</value>
      <webElementGuid>3291fe0f-5e82-442a-8e45-fbcb7202b2d1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;hmenu-content&quot;)/ul[@class=&quot;hmenu hmenu-visible hmenu-translateX&quot;]/li[15]/a[@class=&quot;hmenu-item&quot;]/div[1]</value>
      <webElementGuid>7c972575-afe7-4688-9c6b-bf1c56287de3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='hmenu-content']/ul/li[15]/a/div</value>
      <webElementGuid>2967fe72-8b92-415d-b4bc-11a807a8ed15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[15]/a/div</value>
      <webElementGuid>747c4cd1-f737-4dee-9f65-6a9b455406fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Mobiles, Computers' or . = 'Mobiles, Computers')]</value>
      <webElementGuid>3b0e859c-dfc5-49f7-abd4-c5ac0d6e9960</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
