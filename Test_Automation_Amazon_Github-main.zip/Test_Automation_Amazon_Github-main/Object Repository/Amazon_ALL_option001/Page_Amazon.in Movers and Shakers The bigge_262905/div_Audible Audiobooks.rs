<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Audible Audiobooks</name>
   <tag></tag>
   <elementGuidId>4fea872e-b17e-4c4b-9b74-e9cea14a7c54</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='hmenu-content']/ul/li[10]/a/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(10) > a.hmenu-item > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>feed80d8-e25a-4e83-8fb7-27fda225a03c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Audible Audiobooks</value>
      <webElementGuid>21418eea-1d99-414c-b2a0-ec4f4aeebb8f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;hmenu-content&quot;)/ul[@class=&quot;hmenu hmenu-visible hmenu-translateX&quot;]/li[10]/a[@class=&quot;hmenu-item&quot;]/div[1]</value>
      <webElementGuid>11e1a224-2620-4aaa-8b64-66d8a6b6d9b7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='hmenu-content']/ul/li[10]/a/div</value>
      <webElementGuid>725d5fa7-41d2-4898-a437-1a6062bce389</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[10]/a/div</value>
      <webElementGuid>21a1706a-baeb-474d-9359-5fc387f7f7e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Audible Audiobooks' or . = 'Audible Audiobooks')]</value>
      <webElementGuid>89e19a38-bccd-4ea6-8d8e-667a31809fec</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
