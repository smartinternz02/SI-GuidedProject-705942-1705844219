<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Womens Fashion</name>
   <tag></tag>
   <elementGuidId>0149b064-d54f-414c-bbab-5a06600be22b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='hmenu-content']/ul/li[18]/a/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(18) > a.hmenu-item > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>fec87ca5-3754-480c-837e-f095ef8d8cc7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Women's Fashion</value>
      <webElementGuid>a3fc1dd2-0237-454b-84ba-06571b9c0e84</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;hmenu-content&quot;)/ul[@class=&quot;hmenu hmenu-visible hmenu-translateX&quot;]/li[18]/a[@class=&quot;hmenu-item&quot;]/div[1]</value>
      <webElementGuid>78a47113-f8c9-49da-b9ba-742e33344ed8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='hmenu-content']/ul/li[18]/a/div</value>
      <webElementGuid>e85340df-b4fd-4953-8f80-503a8e474596</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[18]/a/div</value>
      <webElementGuid>287d1cc4-ba47-4c10-b70d-4410f357c5da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;Women&quot; , &quot;'&quot; , &quot;s Fashion&quot;) or . = concat(&quot;Women&quot; , &quot;'&quot; , &quot;s Fashion&quot;))]</value>
      <webElementGuid>a7b13d55-6719-4ea1-a6ee-d5d892410825</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
