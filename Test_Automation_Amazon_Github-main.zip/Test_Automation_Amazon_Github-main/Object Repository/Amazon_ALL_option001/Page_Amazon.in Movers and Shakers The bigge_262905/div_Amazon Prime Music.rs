<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Amazon Prime Music</name>
   <tag></tag>
   <elementGuidId>3b3e7a01-ee5f-4fe6-8d51-908ba4cdc53a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='hmenu-content']/ul/li[12]/a/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(12) > a.hmenu-item > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>2652b9b2-b524-4602-8ed3-a8ff3decf676</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Amazon Prime Music</value>
      <webElementGuid>88551a9b-6079-4a27-be2a-084f94a4ee76</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;hmenu-content&quot;)/ul[@class=&quot;hmenu hmenu-visible hmenu-translateX&quot;]/li[12]/a[@class=&quot;hmenu-item&quot;]/div[1]</value>
      <webElementGuid>0f695fca-ba83-4bbd-8843-ea10f751d598</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='hmenu-content']/ul/li[12]/a/div</value>
      <webElementGuid>e51e4529-e7e3-4412-8e21-1940a5f69fc2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[12]/a/div</value>
      <webElementGuid>707d666d-9c89-4b9a-9e1d-2bc4fa3355d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Amazon Prime Music' or . = 'Amazon Prime Music')]</value>
      <webElementGuid>d8982d96-7785-4d93-8376-17230049f0bf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
