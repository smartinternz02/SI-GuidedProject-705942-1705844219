<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Shop on Amazon Business</name>
   <tag></tag>
   <elementGuidId>5b07bd4a-4705-4279-8d59-8729c64435e4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#ab-sign-in-ingress-link > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='ab-sign-in-ingress-link']/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>de09ff05-1f7b-4675-b3a8-9175f5e66f96</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            Shop on Amazon Business
        </value>
      <webElementGuid>ac97e0f7-1412-476f-a8f4-8998e9f88039</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ab-sign-in-ingress-link&quot;)/span[1]</value>
      <webElementGuid>04386e4e-eeab-418d-8724-11cc2b962449</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='ab-sign-in-ingress-link']/span</value>
      <webElementGuid>4c4da8a5-3d84-464c-8046-3e4fa8016c81</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/a/span</value>
      <webElementGuid>88ec1d53-a6ee-4600-b969-8426e932db47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
            Shop on Amazon Business
        ' or . = '
            Shop on Amazon Business
        ')]</value>
      <webElementGuid>27cf9f63-f65d-4140-a509-07dac5887e2e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
