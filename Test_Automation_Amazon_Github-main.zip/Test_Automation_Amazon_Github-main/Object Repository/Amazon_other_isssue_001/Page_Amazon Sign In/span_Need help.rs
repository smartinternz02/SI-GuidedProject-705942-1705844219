<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Need help</name>
   <tag></tag>
   <elementGuidId>1336bfb7-e33f-4b79-8e03-41695c5014f3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.a-expander-prompt</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='authportal-main-section']/div[2]/div[2]/div/form/div/div/div/div[3]/div/a/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>00d20271-0097-4382-b8d3-bdbf730ee3a4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-expander-prompt</value>
      <webElementGuid>8d8a9378-77d6-49d1-a58d-e4af9dcf3773</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      Need help?
    </value>
      <webElementGuid>67e4164b-a7d8-4ada-b725-b324c0ab4334</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;authportal-main-section&quot;)/div[@class=&quot;a-section auth-pagelet-container&quot;]/div[@class=&quot;a-section a-spacing-base&quot;]/div[@class=&quot;a-section&quot;]/form[@class=&quot;auth-validate-form auth-real-time-validation a-spacing-none&quot;]/div[@class=&quot;a-section&quot;]/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner a-padding-extra-large&quot;]/div[@class=&quot;a-section&quot;]/div[@class=&quot;a-row a-expander-container a-expander-inline-container&quot;]/a[@class=&quot;a-expander-header a-declarative a-expander-inline-header a-link-expander&quot;]/span[@class=&quot;a-expander-prompt&quot;]</value>
      <webElementGuid>8043c0d0-7261-44ba-8b90-3ef1c33a9914</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='authportal-main-section']/div[2]/div[2]/div/form/div/div/div/div[3]/div/a/span</value>
      <webElementGuid>73a7d08e-42a6-4f08-882e-f50d6d03b9e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/span</value>
      <webElementGuid>27255563-fa00-4453-af27-629d7c631407</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
      Need help?
    ' or . = '
      Need help?
    ')]</value>
      <webElementGuid>f50cf4c8-4193-4867-862c-61cd6551f44d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
