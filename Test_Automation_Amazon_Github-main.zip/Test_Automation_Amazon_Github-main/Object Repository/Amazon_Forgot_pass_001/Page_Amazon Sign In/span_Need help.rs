<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Need help</name>
   <tag></tag>
   <elementGuidId>a03d2b8d-5269-4bd6-9c3f-8e1908323fd5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.a-expander-prompt</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='authportal-main-section']/div[2]/div[2]/div/form/div/div/div/div[3]/div/a/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>4514dd12-3cec-4ecf-b7d0-819ded6f5c39</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-expander-prompt</value>
      <webElementGuid>a7cedf2a-f2f4-47d8-acca-0fb4374ec36f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      Need help?
    </value>
      <webElementGuid>2c0d12c7-a682-4928-951d-f9db463235c8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;authportal-main-section&quot;)/div[@class=&quot;a-section auth-pagelet-container&quot;]/div[@class=&quot;a-section a-spacing-base&quot;]/div[@class=&quot;a-section&quot;]/form[@class=&quot;auth-validate-form auth-real-time-validation a-spacing-none&quot;]/div[@class=&quot;a-section&quot;]/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner a-padding-extra-large&quot;]/div[@class=&quot;a-section&quot;]/div[@class=&quot;a-row a-expander-container a-expander-inline-container&quot;]/a[@class=&quot;a-expander-header a-declarative a-expander-inline-header a-link-expander&quot;]/span[@class=&quot;a-expander-prompt&quot;]</value>
      <webElementGuid>f32329bd-8886-437e-bb65-4c620fcfc56a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='authportal-main-section']/div[2]/div[2]/div/form/div/div/div/div[3]/div/a/span</value>
      <webElementGuid>87e4233f-0ac2-48a4-9bc1-e6b75ba4e85d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/span</value>
      <webElementGuid>a3dbad57-975f-4f38-83fb-3762db544191</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
      Need help?
    ' or . = '
      Need help?
    ')]</value>
      <webElementGuid>70525581-db4c-4b65-b656-5deabdffe721</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
