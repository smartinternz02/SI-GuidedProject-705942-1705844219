<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Your Orders</name>
   <tag></tag>
   <elementGuidId>94dc7581-84c2-4b7d-8e4e-3069f383b460</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div[5]/div/div/div/div/a/div/div/div/div[2]/h3</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h3.a-spacing-none.a-text-normal</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>e504f1d8-b163-47d1-ad4f-01b52863d7f1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-spacing-none a-text-normal</value>
      <webElementGuid>2d17af37-5a4e-4dc9-b151-769f2db30404</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                    Your Orders
                                                </value>
      <webElementGuid>4f3667e3-bf65-493d-9f08-073e2ff38060</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[1]/div[@class=&quot;a-row&quot;]/div[@class=&quot;a-column a-span12&quot;]/div[@class=&quot;a-section a-spacing-large ss-landing-container-wide&quot;]/div[@class=&quot;a-row a-spacing-large a-spacing-top-micro ss-rich-card-row&quot;]/div[@class=&quot;a-column a-span4&quot;]/a[@class=&quot;a-color-base a-link-normal a-text-normal&quot;]/div[@class=&quot;a-box self-service-rich-card&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-row a-grid-vertical-align a-grid-top&quot;]/div[@class=&quot;a-column a-span9 ss-rich-card-column-text a-span-last&quot;]/h3[@class=&quot;a-spacing-none a-text-normal&quot;]</value>
      <webElementGuid>4a200fb4-672d-4b9e-af9c-e2e7cdfdaba7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div[5]/div/div/div/div/a/div/div/div/div[2]/h3</value>
      <webElementGuid>4743ebcf-a0f4-4255-b1ed-2d4d25a4fe7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h3</value>
      <webElementGuid>d915c6f1-b30e-49ea-94af-7d669139d610</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = '
                                                    Your Orders
                                                ' or . = '
                                                    Your Orders
                                                ')]</value>
      <webElementGuid>0592370e-cbaf-4567-96b1-98d507a853f5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
