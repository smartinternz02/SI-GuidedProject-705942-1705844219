<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Payment Settings</name>
   <tag></tag>
   <elementGuidId>ec22963a-90f6-4442-b2d2-0c4898677847</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div[5]/div/div/div[2]/div[2]/a/div/div/div/div[2]/h3</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>a3fd24f7-f67f-4c98-a741-4d7e0883b8dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-spacing-none a-text-normal</value>
      <webElementGuid>3cd9d10d-40ba-47e2-b9eb-617ca8023ef5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                    Payment Settings
                                                </value>
      <webElementGuid>67a13ea1-3300-4d46-b2b5-491477dc83f9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[1]/div[@class=&quot;a-row&quot;]/div[@class=&quot;a-column a-span12&quot;]/div[@class=&quot;a-section a-spacing-large ss-landing-container-wide&quot;]/div[@class=&quot;a-row a-spacing-large a-spacing-top-micro ss-rich-card-row&quot;]/div[@class=&quot;a-column a-span4&quot;]/a[@class=&quot;a-color-base a-link-normal a-text-normal&quot;]/div[@class=&quot;a-box self-service-rich-card&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-row a-grid-vertical-align a-grid-top&quot;]/div[@class=&quot;a-column a-span9 ss-rich-card-column-text a-span-last&quot;]/h3[@class=&quot;a-spacing-none a-text-normal&quot;]</value>
      <webElementGuid>ef21d3d2-e1cd-47ee-9a93-f7c5f295daa5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div[5]/div/div/div[2]/div[2]/a/div/div/div/div[2]/h3</value>
      <webElementGuid>20f39c97-2a60-478d-89d3-d3b5b84c99eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/a/div/div/div/div[2]/h3</value>
      <webElementGuid>3e4888e3-4163-4705-8845-4c98b4ac0f0f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = '
                                                    Payment Settings
                                                ' or . = '
                                                    Payment Settings
                                                ')]</value>
      <webElementGuid>744013cc-d4da-43f4-98c0-e570ac417381</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
