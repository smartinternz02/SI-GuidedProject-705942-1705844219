<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Manage Prime</name>
   <tag></tag>
   <elementGuidId>09c8c153-ff3d-487d-b555-d889b1449e5d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div[5]/div/div/div[2]/div/a/div/div/div/div[2]/h3</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>9409283c-aa13-40a5-a604-9fa67cade05e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-spacing-none a-text-normal</value>
      <webElementGuid>cfdec23f-13c8-43be-a0cd-a266db968655</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                    Manage Prime
                                                </value>
      <webElementGuid>10c8b245-ca57-4a8d-9d44-b33ac3405e38</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[1]/div[@class=&quot;a-row&quot;]/div[@class=&quot;a-column a-span12&quot;]/div[@class=&quot;a-section a-spacing-large ss-landing-container-wide&quot;]/div[@class=&quot;a-row a-spacing-large a-spacing-top-micro ss-rich-card-row&quot;]/div[@class=&quot;a-column a-span4&quot;]/a[@class=&quot;a-color-base a-link-normal a-text-normal&quot;]/div[@class=&quot;a-box self-service-rich-card&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-row a-grid-vertical-align a-grid-top&quot;]/div[@class=&quot;a-column a-span9 ss-rich-card-column-text a-span-last&quot;]/h3[@class=&quot;a-spacing-none a-text-normal&quot;]</value>
      <webElementGuid>70033726-fe06-4fd5-8320-00303bdc486d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div[5]/div/div/div[2]/div/a/div/div/div/div[2]/h3</value>
      <webElementGuid>70aa2147-5fc6-4026-9765-cf57204f93e4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/a/div/div/div/div[2]/h3</value>
      <webElementGuid>fe9e23cc-02fa-4b4b-a7fe-6d81e72d6edb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = '
                                                    Manage Prime
                                                ' or . = '
                                                    Manage Prime
                                                ')]</value>
      <webElementGuid>f0f3cfb6-334c-44b0-ab3f-74a76926fdd2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
