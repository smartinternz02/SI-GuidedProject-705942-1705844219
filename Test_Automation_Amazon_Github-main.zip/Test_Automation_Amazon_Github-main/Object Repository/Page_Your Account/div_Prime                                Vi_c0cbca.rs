<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Prime                                Vi_c0cbca</name>
   <tag></tag>
   <elementGuidId>ffc2252b-73b1-4332-bf22-540cae027802</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div/div[2]/div[3]/a/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c4aa5014-b682-484d-95a3-6587516554a8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-box-inner</value>
      <webElementGuid>9d61188c-de5e-4467-94d5-1cb4def750d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            
                
            
            
                
                    Prime
                
                View benefits and payment settings
                
            
        
    </value>
      <webElementGuid>a4932df5-3bfb-4a5b-8547-c5fd671419c2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-container&quot;]/div[@class=&quot;a-section ya-personalized&quot;]/div[@class=&quot;ya-card-row&quot;]/div[@class=&quot;ya-card-cell&quot;]/a[@class=&quot;ya-card__whole-card-link&quot;]/div[@class=&quot;a-box ya-card--rich&quot;]/div[@class=&quot;a-box-inner&quot;]</value>
      <webElementGuid>4a59ef98-d540-45c9-acf4-5fe380938467</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div/div[2]/div[3]/a/div/div</value>
      <webElementGuid>b659c82a-5b32-4319-9aa2-823557efbcbf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/a/div/div</value>
      <webElementGuid>fe7f0cc3-b747-441d-b34e-ff458a71d3ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        
            
                
            
            
                
                    Prime
                
                View benefits and payment settings
                
            
        
    ' or . = '
        
            
                
            
            
                
                    Prime
                
                View benefits and payment settings
                
            
        
    ')]</value>
      <webElementGuid>955b102b-430b-4843-9e41-780d02ac6ce1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
