<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Login  security                        _2ed85e</name>
   <tag></tag>
   <elementGuidId>a057e8a1-d88e-4651-8482-ffcba9de7c60</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div/div[2]/div[2]/a/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>8121c521-5f7b-4aa6-a13e-f8e0efdb07ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-box-inner</value>
      <webElementGuid>a1ca93c6-327a-4b13-9d15-ffaa57ccbdbd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            
                
            
            
                
                    Login &amp; security
                
                Edit login, name, and mobile number
                
            
        
    </value>
      <webElementGuid>4d21c82f-5c60-4783-bef4-36bb0031ba86</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-container&quot;]/div[@class=&quot;a-section ya-personalized&quot;]/div[@class=&quot;ya-card-row&quot;]/div[@class=&quot;ya-card-cell&quot;]/a[@class=&quot;ya-card__whole-card-link&quot;]/div[@class=&quot;a-box ya-card--rich&quot;]/div[@class=&quot;a-box-inner&quot;]</value>
      <webElementGuid>3ad06cea-fb9b-4073-acca-e27a4d503ebf</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div/div[2]/div[2]/a/div/div</value>
      <webElementGuid>fad6afc3-b98d-4d81-a3f0-968e1561cc79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/a/div/div</value>
      <webElementGuid>5c536236-4208-4dc8-8720-9d09ef3eb2e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        
            
                
            
            
                
                    Login &amp; security
                
                Edit login, name, and mobile number
                
            
        
    ' or . = '
        
            
                
            
            
                
                    Login &amp; security
                
                Edit login, name, and mobile number
                
            
        
    ')]</value>
      <webElementGuid>e0a73d72-b23f-40fb-af0f-bff2f877bc8c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
